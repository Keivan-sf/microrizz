"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __async = (__this, __arguments, generator) => {
  return new Promise((resolve, reject) => {
    var fulfilled = (value) => {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    };
    var rejected = (value) => {
      try {
        step(generator.throw(value));
      } catch (e) {
        reject(e);
      }
    };
    var step = (x) => x.done ? resolve(x.value) : Promise.resolve(x.value).then(fulfilled, rejected);
    step((generator = generator.apply(__this, __arguments)).next());
  });
};

// index.ts
var index_exports = {};
__export(index_exports, {
  startServer: () => startServer
});
module.exports = __toCommonJS(index_exports);
var import_ws = require("ws");
var import_express = __toESM(require("express"));

// connection.ts
var WSConnection = class {
  constructor(wss) {
    this.wss = wss;
  }
  on(type, cb) {
    if (type == "data") {
      this.wss.on("message", cb);
    } else {
      this.wss.on(type, cb);
    }
  }
  write(data) {
    this.wss.send(data);
  }
  close() {
    this.wss.close();
  }
};

// Handler/handler.ts
var import_net = __toESM(require("net"));

// Handler/utils/address_parsers.ts
var parse_addr = (buffer, offset = 0) => {
  if (buffer.at(offset) == 1) {
    offset += 1;
    const ipv4 = [];
    const address = buffer.subarray(offset, offset + 4);
    for (const byte of address) {
      ipv4.push(byte.toString());
    }
    const port = buffer.readUintBE(offset + 4, 2);
    return { host: ipv4.join("."), port, offset: offset + 6, type: "ipv4" };
  } else if (buffer.at(offset) == 3) {
    offset += 1;
    const domain_len = buffer.at(offset);
    offset += 1;
    if (!domain_len) throw new Error("No length found for domain");
    const address = buffer.subarray(offset, offset + domain_len);
    const port = buffer.readUintBE(offset + domain_len, 2);
    const domain = address.toString();
    return {
      host: domain,
      port,
      offset: offset + domain_len + 2,
      type: "domain"
    };
  } else {
    offset += 1;
    let ipv6str = "";
    for (let b = 0; b < 16; ++b) {
      if (b % 2 === 0 && b > 0) ipv6str += ":";
      ipv6str += (buffer.at(offset + b) < 16 ? "0" : "") + buffer.at(offset + b).toString(16);
    }
    const port = buffer.readUintBE(offset + 16, 2);
    return { host: ipv6str, port, offset: offset + 16 + 2, type: "ipv6" };
  }
};
var ip_to_buffer = (ipv4, port) => {
  const ip_buffer = Buffer.from(ipv4.split(".").map((chunk) => +chunk));
  const port_buffer = Buffer.allocUnsafe(2);
  port_buffer.writeUIntBE(port, 0, 2);
  return Buffer.concat([ip_buffer, port_buffer]);
};
var ipv6_to_buffer = (ipv6, port) => {
  const chunks = ipv6.split(":");
  const ip_buffer = Buffer.allocUnsafe(16);
  let i = 0;
  for (const chunk of chunks) {
    const first_part = chunk[0] + chunk[1];
    const second_part = chunk[2] + chunk[3];
    ip_buffer.writeUInt8(parseInt(first_part, 16), i++);
    ip_buffer.writeUInt8(parseInt(second_part, 16), i++);
  }
  const port_buffer = Buffer.allocUnsafe(2);
  port_buffer.writeUIntBE(port, 0, 2);
  return Buffer.concat([ip_buffer, port_buffer]);
};

// Handler/handler.ts
var import_dgram = __toESM(require("dgram"));
var COMMANDS = {
  // Task specific commands (0-127)
  CONNECT: 1,
  DATA: 2,
  UDP_ASSOCIATE: 3,
  UDP_DATA: 4,
  SERVER_CLOSE_TASK: 126,
  CLIENT_CLOSE_TASK: 127,
  // General commands (128-255)
  HEART_BEAT: 255,
  AUTH: 128,
  NEW_TASK: 129
};
var ERRORS = {
  BAD_UNAME_PW: 1,
  TID_EXISTS: 2,
  NO_CONNECTION_ON_TASK: 3,
  TID_NOT_FOUND: 4,
  NO_UDPSOCKET_ON_TASK: 5
};
var Client = class {
  constructor(connection, timeout, heart_beat_interval = 2e3) {
    this.connection = connection;
    this.timeout = timeout;
    this.heart_beat_interval = heart_beat_interval;
    this.tasks = /* @__PURE__ */ new Map();
    this.keepAlive();
    setInterval(() => {
      console.log("number of stored tasks", this.tasks.size);
    }, 1e4);
    connection.on("data", (data) => {
      if (!data || data.length < 1) return;
      if (data.at(0) < 128) {
        try {
          this.handleTaskSpecificCommand(data);
        } catch (err) {
          console.log("error handling task specific command", data.at(0), err);
        }
        return;
      } else {
        try {
          this.handleClientSpecificCommand(data);
        } catch (err) {
          console.log(
            "error handling client specific command",
            data.at(0),
            err
          );
        }
      }
    });
  }
  keepAlive() {
    setInterval(() => {
      this.connection.write(Buffer.from([COMMANDS.HEART_BEAT]));
    }, this.heart_beat_interval);
  }
  handleTaskSpecificCommand(data) {
    var _a2;
    const TID = data.readUIntBE(1, 2);
    const task = this.tasks.get(TID);
    if (!task) {
      this.connection.write(
        Buffer.concat([
          Buffer.from([0, (_a2 = data.at(0)) != null ? _a2 : 0]),
          data.subarray(1, 3),
          Buffer.from([ERRORS.TID_NOT_FOUND])
        ])
      );
      return;
    }
    task.last_activity = Date.now();
    if (data.at(0) == COMMANDS.CONNECT) {
      this.handleConnectCmd(task, data);
    } else if (data.at(0) == COMMANDS.DATA) {
      this.handleDataCmd(task, data);
    } else if (data.at(0) == COMMANDS.UDP_ASSOCIATE) {
      this.handleUdpAssociateCmd(task, data);
    } else if (data.at(0) == COMMANDS.UDP_DATA) {
      this.handleUdpDataCmd(task, data);
    } else if (data.at(0) == COMMANDS.CLIENT_CLOSE_TASK) {
      this.handleCloseTaskCmd(task);
    }
  }
  handleClientSpecificCommand(data) {
    if (data.at(0) == COMMANDS.AUTH) {
      this.authenticate(data);
    } else if (data.at(0) == COMMANDS.NEW_TASK) {
      this.createTask(data);
    }
  }
  handleDataCmd(task, data) {
    if (!task.connection) {
      const b = Buffer.allocUnsafe(5);
      b.writeUInt8(0);
      b.writeUInt8(COMMANDS.DATA, 1);
      b.writeUintBE(task.id, 2, 2);
      b.writeUInt8(ERRORS.NO_CONNECTION_ON_TASK, 4);
      this.connection.write(b);
      return;
    }
    task.connection.write(data.subarray(3));
  }
  handleUdpAssociateCmd(task, data) {
    task.udpSocket = import_dgram.default.createSocket("udp4");
    task.udpSocket.on("message", (message, info) => {
      task.last_activity = Date.now();
      const prefix = Buffer.allocUnsafe(4);
      let ip_buffer;
      prefix.writeUint8(COMMANDS.UDP_DATA);
      prefix.writeUintBE(task.id, 1, 2);
      prefix.writeUint8(0, 3);
      this.connection.write(Buffer.concat([b, data]));
      if (info.family == "IPv4") {
        ip_buffer = Buffer.concat([
          Buffer.from([1]),
          ip_to_buffer(info.address, info.port)
        ]);
      } else {
        ip_buffer = Buffer.concat([
          Buffer.from([4]),
          ipv6_to_buffer(info.address, info.port)
        ]);
      }
      const res = Buffer.concat([prefix, ip_buffer, message]);
      this.connection.write(res);
    });
    const b = Buffer.allocUnsafe(3);
    b.writeUInt8(COMMANDS.UDP_ASSOCIATE);
    b.writeUintBE(task.id, 1, 2);
    this.connection.write(b);
  }
  handleUdpDataCmd(task, data) {
    if (!task.udpSocket) {
      const b = Buffer.allocUnsafe(5);
      b.writeUInt8(0);
      b.writeUInt8(COMMANDS.UDP_DATA, 1);
      b.writeUintBE(task.id, 2, 2);
      b.writeUInt8(ERRORS.NO_UDPSOCKET_ON_TASK, 4);
      this.connection.write(b);
      return;
    }
    const { host, port, offset } = parse_addr(data, 4);
    const message = data.subarray(offset);
    task.udpSocket.send(message, port, host);
  }
  handleCloseTaskCmd(task) {
    this.closeTask(task, false);
    const b = Buffer.allocUnsafe(3);
    b.writeUint8(COMMANDS.CLIENT_CLOSE_TASK);
    b.writeUIntBE(task.id, 1, 2);
    this.connection.write(b);
  }
  closeTask(task, sendCloseCommandToClient = true) {
    console.log("closed", task.id);
    if (task.interval) {
      clearInterval(task.interval);
    }
    if (task.connection) {
      if (!task.connection.destroyed) task.connection.destroy();
    }
    if (task.udpSocket) {
      try {
        task.udpSocket.close();
      } catch (err) {
      }
    }
    this.tasks.delete(task.id);
    if (sendCloseCommandToClient) {
      const b = Buffer.allocUnsafe(3);
      b.writeUint8(COMMANDS.SERVER_CLOSE_TASK);
      b.writeUIntBE(task.id, 1, 2);
      this.connection.write(b);
    }
  }
  handleConnectCmd(task, data) {
    const { port, host } = parse_addr(data, 3);
    task.connection = import_net.default.createConnection({ host, port });
    task.connection.on("error", () => {
      this.closeTask(task);
    });
    task.connection.on("close", () => {
      this.closeTask(task);
    });
    task.connection.once("connect", () => {
      var _a2, _b;
      task.last_activity = Date.now();
      task.state = "connected";
      const b = Buffer.allocUnsafe(4);
      b.writeUInt8(COMMANDS.CONNECT);
      b.writeUintBE(task.id, 1, 2);
      b.writeUint8(1, 3);
      const ip_buffer = ip_to_buffer(
        (_a2 = task.connection) == null ? void 0 : _a2.localAddress,
        (_b = task.connection) == null ? void 0 : _b.localPort
      );
      this.connection.write(Buffer.concat([b, ip_buffer]));
    });
    task.connection.on("data", (data2) => {
      task.last_activity = Date.now();
      const b = Buffer.allocUnsafe(3);
      b.writeUInt8(COMMANDS.DATA);
      b.writeUintBE(task.id, 1, 2);
      this.connection.write(Buffer.concat([b, data2]));
    });
  }
  createTask(data) {
    const TID = data.readUIntBE(1, 2);
    if (this.tasks.has(TID)) {
      this.connection.write(
        Buffer.from([0, COMMANDS.NEW_TASK, ERRORS.TID_EXISTS])
      );
      return;
    }
    const task = { id: TID, state: "opened", last_activity: Date.now() };
    const interval = setInterval(() => {
      if (Date.now() - task.last_activity > this.timeout) {
        console.log("closing due to timeout", TID);
        this.closeTask(task, true);
      }
    }, this.timeout);
    task.interval = interval;
    this.tasks.set(TID, task);
    const res = Buffer.allocUnsafe(3);
    res.writeUInt8(COMMANDS.NEW_TASK);
    res.writeUIntBE(TID, 1, 2);
    this.connection.write(res);
  }
  authenticate(data) {
    const IDLEN = data.at(1);
    const ID = data.subarray(2, IDLEN + 2);
    const PWLEN = data.at(IDLEN + 2);
    const PW = data.subarray(IDLEN + 3, PWLEN + IDLEN + 3);
    if (ID.toString() == "admin" && PW.toString() == "adminpw") {
      this.connection.write(Buffer.from([128]));
    } else {
      this.connection.write(
        Buffer.from([0, COMMANDS.AUTH, ERRORS.BAD_UNAME_PW])
      );
    }
  }
};

// Utils/NetworkImbalancer.ts
var import_axios = __toESM(require("axios"));

// Utils/sleep.ts
var sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

// Utils/NetworkImbalancer.ts
var NetworkImbalancer = class {
  constructor(targets, interval) {
    this.targets = targets;
    this.interval = interval;
  }
  start() {
    return __async(this, null, function* () {
      let i = 0;
      while (true) {
        if (i > this.targets.length - 1) {
          i = 0;
        }
        import_axios.default.get(this.targets[i]).catch((err) => {
          console.log("axios err", err);
        });
        i++;
        yield sleep(this.interval);
      }
    });
  }
};

// index.ts
var import_dotenv = require("dotenv");

// Lib/WRTC.ts
var import_wrtc = require("@roamhq/wrtc");
var WRTCClient = class {
  constructor(id) {
    this.id = id;
    this.ice_candidate_buffer = [];
    this.data_channel = null;
    this.listeners = {};
    this.peer = new import_wrtc.RTCPeerConnection({
      iceServers: [{ urls: "stun:stun.l.google.com:19302" }]
    });
    this.peer.ondatachannel = (e) => {
      this.data_channel = e.channel;
      this.data_channel.onmessage = (ev) => {
        if (this.listeners.ondata) this.listeners.ondata(Buffer.from(ev.data));
      };
      this.data_channel.onclose = () => {
        if (this.listeners.onclose) this.listeners.onclose();
      };
      this.data_channel.onerror = (ev) => {
        if (this.listeners.onerror) this.listeners.onerror(ev);
      };
      this.data_channel.onopen = () => {
        if (this.listeners.onconnection) this.listeners.onconnection();
      };
    };
    this.peer.onicecandidate = (ev) => {
      if (!ev.candidate) return;
      this.ice_candidate_buffer.push(ev.candidate);
    };
  }
  write(data) {
    if (!this.data_channel)
      throw new Error("Data channel does not exist for writing");
    this.data_channel.send(data);
  }
  on(type, cb) {
    if (type == "data") {
      this.listeners.ondata = cb;
    } else if (type == "close") {
      this.listeners.onclose = cb;
    } else if (type == "error") {
      this.listeners.onerror = cb;
    } else if (type == "connection") {
      this.listeners.onconnection = cb;
    }
  }
  close() {
    this.peer.onicecandidate = null;
    this.peer.ontrack = null;
    this.peer.ondatachannel = null;
    this.peer.onicecandidateerror = null;
    this.peer.onnegotiationneeded = null;
    this.peer.onsignalingstatechange = null;
    this.peer.onconnectionstatechange = null;
    this.peer.onicegatheringstatechange = null;
    this.peer.oniceconnectionstatechange = null;
    this.peer.oniceconnectionstatechange = null;
    if (this.data_channel) {
      this.data_channel.onmessage = null;
      this.data_channel.onopen = null;
      this.data_channel.onclose = null;
      this.data_channel.onerror = null;
      this.data_channel.onclosing = null;
      this.data_channel.onbufferedamountlow = null;
    }
    this.peer.close();
  }
  getAnswer(offer) {
    return __async(this, null, function* () {
      yield this.peer.setRemoteDescription(offer);
      const answer = yield this.peer.createAnswer();
      this.peer.setLocalDescription(answer);
      return answer;
    });
  }
  addCandidate(ice) {
    this.peer.addIceCandidate(ice);
  }
  getIceCandidates() {
    const candidates = this.ice_candidate_buffer;
    this.ice_candidate_buffer = [];
    return candidates;
  }
};

// index.ts
(0, import_dotenv.config)();
var _a;
var PORT = (_a = process.env.PORT) != null ? _a : 3e3;
var TIME_OUT = 15e3;
function handle_wrtc_connection(client) {
  client.on("connection", () => {
    new Client(client, TIME_OUT);
  });
}
function routeWRTC(router) {
  let id_counter = 0;
  const wrtcClients = [];
  router.get("/initiate", (req, res) => {
    const id = ++id_counter;
    const client = new WRTCClient(id);
    handle_wrtc_connection(client);
    wrtcClients.push(client);
    res.send({ id });
  });
  router.post("/offer", (req, res) => __async(null, null, function* () {
    const client = wrtcClients.find((w) => w.id == req.body.id);
    if (!client) {
      res.statusCode = 400;
      res.send({ msg: `no client found with id ${req.body.id}` });
      return;
    }
    console.log("offer:", req.body);
    const answer = yield client.getAnswer(req.body.offer);
    res.send({ id: req.body.id, answer });
  }));
  router.post("/get-ice-candidate", (req, res) => {
    const client = wrtcClients.find((w) => w.id == req.body.id);
    if (!client) {
      res.statusCode = 400;
      res.send({ msg: `no client found with id ${req.body.id}` });
      return;
    }
    res.send({ id: client.id, candidates: client.getIceCandidates() });
  });
  router.post("/send-ice-candidate", (req, res) => {
    const client = wrtcClients.find((w) => w.id == req.body.id);
    if (!client) {
      res.statusCode = 400;
      res.send({ msg: `no client found with id ${req.body.id}` });
      return;
    }
    console.log("added new candidate from client");
    client.addCandidate(req.body.candidate);
    res.sendStatus(200);
  });
}
var startServer = () => {
  const app = (0, import_express.default)();
  app.use(import_express.default.json());
  app.get("/", (req, res) => {
    res.send("<html><h4>Work in progress...</h4></br>Coming soon</html>");
  });
  const wrtc_router = import_express.default.Router();
  routeWRTC(wrtc_router);
  app.use("/webrtc", wrtc_router);
  const server2 = app.listen(PORT);
  const wss = new import_ws.WebSocketServer({ server: server2 });
  wss.on("connection", (ws) => {
    new Client(new WSConnection(ws), TIME_OUT);
  });
  wss.on("listening", () => {
    console.log(`wss is listening on port ${PORT}`);
  });
  const imbalaner = new NetworkImbalancer(["http://time.ir"], 5e3);
};
startServer();
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  startServer
});
